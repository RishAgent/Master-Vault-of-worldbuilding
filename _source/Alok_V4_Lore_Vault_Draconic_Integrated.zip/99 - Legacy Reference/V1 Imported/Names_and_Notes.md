---
tags: [legacy, v1, reference]
status: legacy
source: Names_and_Notes.txt
---
# Names and Notes — V1 Legacy

> [!warning] Legacy only
> Preserved for mining ideas. Old ranks, levels, stats, prices and mechanics are not current canon unless reintroduced in active notes.

Zeyria Hilderborne - fourth princess of ZelderDracos


[Soul Bond Established] You have received:
• 1 Demon Noble (Quereza Ashton) LVL 497
• 10 Elite Demons LVL 200–299
• 100 Greater Demons LVL 150–199
• 1 Valkyrie Monarch (Hiria Inksworth) LVL 729
• 10 Valkyrie Paragons LVL 200–499
• 50 Valkyrie Champions LVL 100–199
• 1 Grand Angel Knight (Liera Weirce) LVL 499
• 50 Angel Knights LVL 100–199
• 1 Fourth Tier Dragonoid Grand Knight (Dunkan Arkhreign) LVL 499
• 50 Third Tier Dragonoid Knights LVL 199



[Soul Bond Established] You have received:
•	1 Demon Lord (Baneroth) LVL 1023
•	1 Fifth-Tier Demonoid (Riwald) LVL 645
•	1 Valkyrie Monarch (Lucien) LVL 623
•	10 Death Knights LVLs around 85
•	50 Undead Elite Soldiers LVLs around 40.


Alok's world

Mage system:
Apprentice Mage
Mage
Senior Mage - One Star LVL 20
Elite Mage - Two star  LVL 40
Grand Mage - Three Star LVL 70
Great Mage - Four Star LVL 100
Arch Mage  - 


Knight System:

Apprentice Knight
Training Knight
Knight
Senior Knight
Elite Knight
Grand Knight
Great Knight
Swordmaster


Ludwick Krayz