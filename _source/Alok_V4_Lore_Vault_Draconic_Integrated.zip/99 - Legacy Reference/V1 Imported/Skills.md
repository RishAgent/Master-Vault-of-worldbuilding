---
tags: [legacy, v1, reference]
status: legacy
source: Skills.txt
---
# Skills — V1 Legacy

> [!warning] Legacy only
> Preserved for mining ideas. Old ranks, levels, stats, prices and mechanics are not current canon unless reintroduced in active notes.

Molten Tempest (Fire + Lightning + Ground)


Description:
Stomps the foot covered in molten rock, causing molten spikes to erupt violently. When the lightning arcs through these spikes, they resonate, sending continuous electric discharges outward, striking multiple enemies and chaining between nearby foes. The combination of molten stone and elemental energy makes this attack extremely destructive and difficult to evade.



Fire Skill – Inferno Pulse (Rank B)

Description:
Alok channels fire into a concentrated pulse that explodes outward from a point he chooses, creating a ring of intense flames. The pulse spreads rapidly in all directions, incinerating enemies caught in its radius while leaving concentrated fire streaks that continue burning for a short duration.

Storm Breaker (Rank B, Lightning Manipulation)



Description:
Alok channels a massive surge of concentrated lightning into a focused radius around him or a selected point. The skill creates overhead lightning strikes that continuously chain between enemies in the area. The concentrated energy fractures the ground and emits bursts of electric arcs, dealing sustained damage for a short duration.



Area Burst Damage: The initial strike hits a large radius, immediately damaging all enemies caught.

Chained Lightning: Electricity arcs continuously from enemy to enemy within range, allowing damage to multiply on clustered targets.

Ground Resonance: The lightning interacts with metallic or conductive surfaces (including his stone gauntlet or weapons) to extend arcs further.

