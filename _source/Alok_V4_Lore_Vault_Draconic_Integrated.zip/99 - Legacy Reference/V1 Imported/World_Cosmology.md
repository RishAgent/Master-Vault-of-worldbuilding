---
tags: [legacy, v1, reference]
status: legacy
source: World_Cosmology.txt
---
# World Cosmology — V1 Legacy

> [!warning] Legacy only
> Preserved for mining ideas. Old ranks, levels, stats, prices and mechanics are not current canon unless reintroduced in active notes.

WORLD COSMOLOGY

1) FOUNDATIONAL DIVINE PARENTS
------------------------------
Above all Pantheons—embodying Life and Death:

• Azrakel (God of Death, Supreme, Lord of the Final Passage):
  Chief among the Death gods; all gods of death across worlds hold only a fragment of his true domain.

• Seraphae (Goddess of Life, Supreme, Lady of the Breath):
  Chief above all gods of life and growth; every goddess of birth, nurture, and spring draws but a spark of her essence.

—Alok is their son, a rare fusion of the two primal forces, watched intently by all lesser gods.

2) THE PANTHEONS AND EMPYREAN REGISTRY
--------------------------------------
A. OLYMPIAN AND GREEK LINEAGE:
Hermes • Athena • Ares • Dionysus • Poseidon • Charybdis • Antaeus • Thanatos • Orion • Triton • Persephone • Hades • Zeus • Hera • Demeter • Hestia • Apollo • Artemis • Brontes • Steropes • Arges • Nike • Nemesis

B. NORSE AESIR AND VANIR:
Odin • Thor • Heimdall • Urd • Skuld • Verdandi • Freya

C. HINDU:
Shiva • Chandra

D. CELTIC:
Cernunnos

E. CHINESE/JADE DYNASTY:
Jade Emperor • Erlang Shen • Prince Nezha • Leizhenzi • West Empress Dowager • Daode Tianzun • Lingbao Tianzun • Sanhuang Wudi • Kiku • Ji • Li Ju • Snapping Turtle

F. ABRAHAMIC:
Gabriel • Michael • Metatron

G. EGYPTIAN:
Ra • Anubis • Montu

H. BALTIC & OTHERS:
Giltinė (Lithuanian death goddess) • Sulė (sun goddess)

I. SLAVIC:
Dazhbog • Nevadba

J. JAPANESE-INSPIRED/ORIGINAL:
Arashi • Arte • Ratu • Allardi • Dun Cow (Dun Cow from English folklore; others—unique or local spirits)

3) DEMONS & DEVILS—THE INFERNAL HOST
------------------------------------
NATURE:
Demons/Devils are a distinct, non-human ancient race, not inherently evil but chaotic, cunning, and capable of harboring immense and unique powers.

POTENTIAL FOR GROWTH:
Powerful demons can rival or even surpass the might of the highest gods or Elder Dragons.

HIERARCHY:
Newborns/Imps → Greater Demons → Archdemons → Demon Lords → Demon Kings/Queens → Primordial Demons (legendary)

DOMAINS:
Ranging from chaos, temptation, destruction, to dreams, despair, lust, hunger, and the primordial forces.

UNIQUE DEMON NOBILITY:
• Lilith (Queen of Temptation, Night)
• Ravana (King of Conquest, War)
• Baal (Lord of Discord)
• Abaddon (Destruction)
• Belial (Corruption)
• Asmodeus (Lust)
• Mara (Desire/Illusion)

4) WORLD STRUCTURE & INTERACTIONS
---------------------------------
PANTHEONS GOVERN FRAGMENTS:
For every cosmic concept (like Death, Life, Thunder, War), most pantheons possess a representative, but only Azrakel and Seraphae embody the primal essence above all.

GODLY HIERARCHY:
Supreme (Azrakel/Seraphae) → Major Pantheon Deities (e.g., Hades, Ra, Odin, Shiva) → Minor Deities & Spirits

DEMONIC COUNTERBALANCE:
Demons and Devils exploit unguarded realms, forging so-called "hells," but are as likely to aid as to destroy—depending on their contracts, chaos, or ambition.

THE TOWER:
A neutral testing ground that attracts the gaze of all—god, demon, and mortal. Its trials call forth the interest and wagers of every divine/demonic power.
