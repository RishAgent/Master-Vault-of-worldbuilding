---
tags: [legacy, v1, reference]
status: legacy
source: Bestiary.txt
---
# Bestiary — V1 Legacy

> [!warning] Legacy only
> Preserved for mining ideas. Old ranks, levels, stats, prices and mechanics are not current canon unless reintroduced in active notes.

Gate Rank A


Species Line: Frost Lupinid

A mana-mutated predator species born from prolonged exposure to cold-aspected mana and corpse-saturated ruins. Not undead, not beasts—proto-humanoids in evolution.

Stage I — Frost Lupinid (Levels 50–75)

Form: Predominantly wolf-like, proto-humanoid

Physiology

Quadrupedal but capable of brief upright movement

Elongated forelimbs with partially articulated digits

Jaw structure closer to humanoid than wolf

Fur sparse in places, exposing frost-hardened skin

Eyes show low-level reasoning but no true intelligence

Combat Traits

Cold-Adapted Musculature: Movement unaffected by snow or ice

Pack Instinct: Coordinated flanking behavior

Rending Bite: Tears armor and flesh efficiently

Frost Vein Response: Bleeding wounds slow victims via cold mana seepage

Behavior

Operates in packs of 6–12

Attacks weaker or isolated targets first

Withdraws if pack loses more than 40% members

Narrative Role

Establishes early unease: wolves that almost stand

Serves as attrition pressure rather than lethal threat

Stage II — Ascendant Lupinid (Levels 75–100)

Form: Semi-humanoid predator

Physiology

Upright posture sustainable for extended combat

Broad shoulders, elongated arms ending in clawed hands

Facial structure clearly humanoid, though bestial

Tail shortened or partially atrophied

Vocal cords capable of complex sounds (not language)

Combat Traits

Crude Tool Usage: Can wield clubs, scavenged blades, debris

Adaptive Hide: Defense increases as body temperature drops

Territory Awareness: Uses ruins, rooftops, and fog tactically

Feral Tactics: Targets healers and mages deliberately

Behavior

Packs led by the strongest individual

Demonstrates rudimentary strategy

Begins to show dominance hierarchies

Narrative Role

Confirms these are not beasts

Forces hunters to fight thinking enemies

Where Naeva first notices “they’re watching us”

Stage III — Divergence Point (Levels 100–125)

At this stage, evolution branches.

Instinct drives most down the Monster Path.
Sentience requires external intervention, suppressed instinct, or unique influence.

In this gate, only the Monster Path exists naturally.

Stage III-A — Feral Lupinid Brute (Monster Path, Levels 100–125)

Form: Fully humanoid monster

Physiology

Permanently bipedal

Massive musculature, disproportionate strength

Hands capable of manipulation but used for violence only

Thickened frost-plated skin

Jaw structure optimized for tearing, not speech

Combat Traits

Cold Mana Overdrive: Strength increases in blizzards

Frost Rend: Attacks inflict stacking cold trauma

Predator Suppression: Emits pressure that weakens lower monsters

Pain Negation: Continues fighting through fatal injuries

Behavior

No retreat behavior

Will fight until death

Attacks strongest opponent instinctively

Narrative Role

True A-rank threats

Function as roaming elites or sub-bosses

Demonstrates what happens when evolution favors power over reason