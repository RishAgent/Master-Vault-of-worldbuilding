---
title: Alok Aeonmorta — Intermediate Silver / Fourfold Racial Manifestation
aliases:
  - Alok Intermediate Silver Status
  - Alok Fourfold Racial Awakening
  - Alok Silver Racial Manifestation Update
tags:
  - story-work
  - alok
  - intermediate-silver
  - racial-awakening
  - affinities
  - elemental-confluence
  - vessel-refinement
status: canon-working-lock
story_phase: Tower Beginner Floors / Intermediate Silver
supersedes:
  - Beginner-Silver combat values in Alok Aeonmorta Current Status V4
  - Beginner-Silver working outputs in Alok Elemental Confluence Spellbook
---

# Alok Aeonmorta — Intermediate Silver / Fourfold Racial Manifestation

> [!important] Canon Scope
> This note records Alok's **Intermediate Silver** state after the first complete Silver-stage manifestation of his four inherited racial lines:
>
> - Dragon
> - Demon
> - Angel
> - Valkyrie
>
> It updates his vessel, Attributes, Mana structure, affinities, racial traits, martial output, Divine Skills, and Elemental Confluence.
>
> His four bloodlines remain **distinct**. This is **not yet a complete Aeonmorta racial merger**.

---

# 1. Scaling Rules Used for This Update

The update is applied in three layers.

## Layer One — Intermediate Silver Breakthrough

Crossing from Beginner Silver into Intermediate Silver grants:

- **+250 STR**
- **+250 AGI**
- **+250 VIT**
- **+250 INT**
- **+250 Divinity**

All existing working Skill and Spell outputs then receive:

# **×1.25 Intermediate-Silver scaling**

This represents the stronger vessel, denser Mana, improved channels, and higher substage.

## Layer Two — Fourfold Racial Vessel Reinforcement

After the substage breakthrough, the developing Dragon / Demon / Angel / Valkyrie vessel provides an additional:

# **×1.20 general output reinforcement**

This applies after the Intermediate-Silver increase.

Combined general multiplier:

# **1.25 × 1.20 = ×1.50**

This multiplier applies before recalculating affinity-dependent damage.

> [!note]
> Alok's existing **Child of Life and Death +20% effective Attribute title bonus** remains separate.
>
> The racial **×1.20 output reinforcement** is not another +20% Attribute multiplier.

## Layer Three — Affinity Recalculation

Old working spell values already included their previous affinity states.

Therefore the new +250% to +350% affinity values are **not simply added again** to the old damage.

Affinity-dependent Skills are recalculated using the ratio between the old effective affinity multiplier and the new one.

This prevents accidental double-counting.

---

# 2. Tier and Progression State

| Field | Current |
|---|---|
| **Tier** | **Intermediate Silver** |
| **Legacy Level** | **48** |
| **Stars** | **★★★ Three-Star** |
| **Personal Rank** | **Divine** |
| **Primary Class** | Sovereign of Eternal Cycle — Unique Divine |
| **Secondary Class** | Astral Thunder Warlord — Mythic |
| **Secondary Class** | Soulforged War Saint — Mythic |
| **Racial State** | Fourfold Silver-Stage Manifestation Complete |
| **Current Overall Refinement** | **~50% toward Advanced Silver** |

---

# 3. Intermediate Silver Breakthrough Attributes

Previous Beginner-Silver base Attributes:

| Attribute | Previous |
|---|---:|
| STR | 3,288 |
| AGI | 3,324 |
| VIT | 3,306 |
| INT | 4,450 |
| Divinity | 6,270 |

Substage breakthrough bonus:

# **+250 each**

Immediate post-breakthrough values:

| Attribute | Post-Breakthrough |
|---|---:|
| STR | 3,538 |
| AGI | 3,574 |
| VIT | 3,556 |
| INT | 4,700 |
| Divinity | 6,520 |

---

# 4. Racial Refinement Toward Advanced Silver

Intermediate Silver → Advanced Silver benchmark gap:

# **4,500 → 8,000**

Gap:

# **3,500**

At Intermediate Silver:

# **1% refinement ≈ +35 benchmark Attribute growth**

## Physical Vessel

Fourfold racial reconstruction pushes the Physical Vessel to approximately:

# **50%**

Balanced benchmark-equivalent growth:

# **+1,750 STR**
# **+1,750 AGI**
# **+1,750 VIT**

## Mana-Core Track

The racial Mana organs push the Mana-Core track to:

# **100%**

Mana-Core benchmark-equivalent growth:

# **+3,500 INT**

The Mana-Core track is therefore saturated for the Intermediate → Advanced stage.

Further compatible magical growth may be held as overflow until the Physical Vessel catches up.

---

# 5. Final Base Attributes

| Attribute | Final Base |
|---|---:|
| **STR** | **5,288** |
| **AGI** | **5,324** |
| **VIT** | **5,306** |
| **INT** | **8,200** |
| **Divinity** | **6,520** |

## Child of Life and Death — +20% Effective Attributes

| Attribute | Base | Effective |
|---|---:|---:|
| STR | 5,288 | **6,346** |
| AGI | 5,324 | **6,389** |
| VIT | 5,306 | **6,367** |
| INT | 8,200 | **9,840** |

---

# 6. Physical Attack Baseline

Universal rule:

# **1 STR = 10 Base Physical AP**

Using title-adjusted effective STR:

# **6,345.6 × 10 = ~63,456 raw physical AP**

This is before:

- weapon amplification
- technique multipliers
- Mana reinforcement
- affinity infusion
- momentum
- armor / gauntlet effects
- Divine reinforcement

---

# 7. Mana

Established rule:

# **1 Base INT = 100 Natural Mana**

At Base INT 8,200:

# **820,000 Natural Mana**

This remains the central visible Mana capacity.

The new racial Mana organs improve:

- Mana density
- compression
- circulation
- throughput
- recovery
- channel durability
- parallel casting load
- affinity conversion

They do **not** currently create separately displayed independent Mana pools.

---

# 8. Mana Recovery

Previous current-status working value:

# **~790 Mana/sec**

Intermediate Silver / racial vessel recovery increase:

# **+40%**

Calculation:

**790 × 1.40 = 1,106**

New working recovery:

# **~1,100 Mana/sec**

This is the normal passive recovery value before:

- meditation
- Soul Space
- external Mana density
- artifacts
- regeneration interaction
- specialized potions
- Divine effects

---

# 9. Divinity

## Pool

Previous:

**6,270**

Intermediate Silver breakthrough:

**+250**

Current:

# **6,520 Divinity**

## Recovery

Previous:

# **600 Divinity/hour**

Increase:

# **+40%**

Current:

# **840 Divinity/hour**

Equivalent:

- **14 Divinity/minute**
- **~0.2333 Divinity/sec**

---

# 10. Racial Mana Organs

The four bloodlines no longer exist only as dormant inheritance.

They now possess functional Silver-stage structures.

## Dragon Heart

A draconic Mana-heart layered into Alok's vessel.

Functions:

- high-density Mana compression
- powerful physical Mana circulation
- enhanced Flame affinity
- enhanced Lightning affinity
- improved scale manifestation
- improved draconic regeneration
- improved breath / elemental discharge architecture
- reinforces STR and VIT-biased vessel growth

The Dragon Heart strongly contributes to Mana-Core saturation.

## Demon Heart

A second racial Mana-heart associated with the Demon lineage.

Functions:

- dense Mana conversion
- Blood affinity enhancement
- Flame affinity enhancement
- improved regeneration
- corruption resistance
- toxin resistance
- hostile-energy tolerance
- stronger demonic markings
- improved Demon Sense
- improved survival under extreme Mana stress

The Demon Heart is especially compatible with Alok's Life / Death reconstruction.

## Angel Core

A pure celestial Mana structure.

Functions:

- extremely clean Mana refinement
- purification
- Light affinity enhancement
- Starlight compatibility
- improved curse resistance
- improved corruption resistance
- improved Divine-Mana conduction
- wing manifestation support
- more stable multi-affinity casting

The Angel Core is one of the primary reasons Alok's Mana-Core track reaches 100%.

## Valkyrie Battle Lattice

The Valkyrie inheritance does not create another major Core.

Instead it forms a growing body-wide battle lattice through:

- nerves
- muscles
- Mana channels
- joints
- weapon pathways
- battle runes

Functions:

- improved combat adaptation
- higher movement efficiency
- faster martial learning
- better weapon synchronization
- improved aerial control
- improved Lightning / Wind compatibility
- improved reaction under lethal pressure

---

# 11. Fourfold Racial Manifestation

Current Silver-stage manifestation:

# **100% — INITIAL MANIFESTATION COMPLETE**

This does **not** mean the bloodlines are fully mature.

Their traits become more defined and complete as Alok advances through:

- Intermediate Silver
- Advanced Silver
- Peak Silver
- Gold
- later Tiers

## Voluntary Manifestation

Alok can now consciously manifest or dismiss racial traits.

Current controllable traits include:

### Dragon

- vertical draconic pupils
- localized scales
- horns
- claws
- draconic wings
- reinforced teeth
- Dragon Vision
- Dragon Heart output

### Demon

- demonic horns
- markings
- claws
- altered pupils
- denser regeneration
- Demon Sense
- Demon Heart output
- hostile-energy resistance

### Angel

- luminous feathered wings
- partial halo / crown-light manifestation
- luminous markings
- purification field
- Angel Core output
- enhanced Light conduction

### Valkyrie

- battle runes
- enhanced war-instinct state
- reinforced weapon pathways
- aerial balance
- rapid combat adaptation
- high-speed martial perception

> [!important]
> Traits may be manifested selectively.
>
> Alok does not need to transform his entire body every time he wants scales, wings, horns, eyes, or racial sensing.

---

# 12. Incomplete Trait Rule

Current traits are Silver-grade expressions.

They are functional—

but not final.

Examples:

- scales cover limited or selected regions rather than a complete mature draconic armor
- horns are smaller and less structurally developed than higher-Tier racial forms
- wings are fully usable but not yet equal to mature high-Tier racial wings
- angelic halo structures are partial
- Valkyrie runes do not yet represent a complete war-body
- racial organs continue densifying with advancement

Each substage makes the manifestations:

- larger
- denser
- more stable
- more energy-efficient
- more resistant
- more complete

---

# 13. Racial Perception

## Dragon Vision

Current state:

**Active / Voluntary**

Functions:

- sees Mana flow with extreme detail
- observes Mana channels
- identifies spell construction
- reads Mana density
- tracks magical motion
- detects unstable magical structures
- improves weak-point targeting
- assists Elemental Confluence

## Demon Sense

Current state:

**Active / Voluntary**

Functions:

- detects directed hostility
- senses malicious intent
- detects killing intent
- improves ambush awareness
- gives instinctive directional threat perception

## Combined Sensory Stack

Dragon Vision + Demon Sense + Worldsense creates a three-layer perception system:

1. **Worldsense** — large-area battlefield awareness
2. **Dragon Vision** — microscopic magical detail
3. **Demon Sense** — hostile intent / threat direction

---

# 14. Affinity Advancement

The fourfold racial manifestation does not raise every affinity equally.

New working affinity values:

| Affinity | Previous Working State | New Damage / Effectiveness |
|---|---:|---:|
| **Blood** | +100% | **+300%** |
| **Lightning** | +120% | **+325%** |
| **Flame** | +100% | **+350%** |
| **Frost** | +100% | **+250%** |
| **Light** | integrated | **+350%** |
| **Lunar** | integrated | **+275%** |
| **Starlight** | integrated | **+300%** |
| **Wind** | integrated | **+300%** |

## Why Some Are Higher

### Flame — +350%

Enhanced by:

- Dragon Heart
- Demon Heart
- draconic elemental architecture
- demonic heat tolerance
- improved Mana density

### Light — +350%

Enhanced by:

- Angel Core
- Divine-Born biology
- purification architecture
- celestial Mana conduction

### Lightning — +325%

Enhanced by:

- Dragon lineage
- Valkyrie battle lattice
- Astral Thunder Warlord
- Thor's existing blessing

### Blood — +300%

Enhanced by:

- Demon Heart
- Life / Death architecture
- Blood Magic experience

### Starlight / Wind — +300%

Enhanced through:

- Angelic / celestial compatibility
- Valkyrie movement structure
- Three-Star architecture

### Lunar — +275%

Highly compatible with Alok's celestial framework, but less directly reinforced by the four racial organs than Light or Starlight.

### Frost — +250%

Receives the full universal affinity improvement, but no major racial specialization bonus at this stage.

---

# 15. Affinity Multiplier Interpretation

A displayed:

**+250% Damage / Effectiveness**

means:

# **×3.5 baseline elemental performance**

A displayed:

**+300%**

means:

# **×4.0**

A displayed:

**+325%**

means:

# **×4.25**

A displayed:

**+350%**

means:

# **×4.5**

These are not multiplied again onto the updated spell values below.

The listed new working outputs already include the new affinity state.

---

# 16. Elemental Confluence — New Stability

Alok remains Three-Star.

He still possesses:

- 3 permanent Core Circles
- 3 projected Casting Circles

However the Dragon Heart, Demon Heart, Angel Core, and stronger vessel greatly improve spell weaving.

## Current Confluence State

| Affinity Count | New State |
|---|---|
| **Two-Affinity** | **Fully Stable** |
| **Three-Affinity** | **Stable** |
| **Four-Affinity** | **Possible / conditionally stable** |
| **Five-Affinity** | **Unstable** |
| **Eightfold Confluence** | **Still unsafe** |

Four-affinity casting becomes much safer when:

- Aetheryn is used as a conduction medium
- Alok has time to prepare
- Parallel Spell Construction is used carefully
- the affinities possess natural compatibility

Eightfold Confluence remains a future milestone.

---

# 17. General Mana Skills — Updated

## Mana Bullet

Previous:

**~4,000 AP**

New:

# **~6,000 AP / bullet**

Mana cost remains approximately:

**100 Mana**

## Parallel Spell Construction

Improved by:

- Intermediate Silver Mana throughput
- saturated Mana-Core track
- Dragon Heart
- Demon Heart
- Angel Core

Three projected Circles remain the normal primary framework.

However each Circle can now maintain more substructures before instability becomes the limiting factor.

## Mana Form

Constructs gain approximately **50% greater working structural force** before elemental reinforcement.

Includes:

- platforms
- shields
- bindings
- blades
- hammers
- projectiles
- temporary structures

---

# 18. Lightning Skills — Updated

## Lightning Zap

# **~35,000 AP**

## Lightning Bolt

# **~350,000 AP**

## Lightning Spear

# **~810,000 AP**

## Thunderstep

Raw movement / vector-control performance improves by approximately:

# **~50%**

Mana cost remains roughly:

**500 Mana per major activation**

Racial wings and Valkyrie aerial control greatly improve mid-air use.

## Astral Storm Mantle

Previous:

- AGI +30%
- Reaction +30%
- Lightning output +20%

New:

- **AGI +45%**
- **Reaction +45%**
- **Lightning output +30%**

Upkeep remains:

**~150 Mana/sec**

---

# 19. Flame Skills — Updated

## Fireball

# **~47,000 AP**

## Supercharged Fireball

# **~95,000 AP**

## Fireblast

# **~162,000 AP**

## Flame Missile

# **~422,000 AP**

Flame spells now carry substantially denser thermal output because Flame has become one of Alok's strongest racial affinities.

---

# 20. Frost Skills — Updated

## Ice Ball

# **~32,000 AP**

## Frost Blast

# **~110,000 AP**

Frost Constructs become approximately **50% stronger structurally** before additional Mana investment.

Frost remains less racially amplified than Flame or Light, but is still dramatically stronger than the Beginner-Silver version.

---

# 21. Blood Skills — Updated

## Blood Crescent

# **~300,000 AP**

## Crimson Avalanche

# **~525,000 AP**

Radius remains context-dependent.

Demon Heart development improves:

- Blood control
- blood sensing
- internal manipulation
- Blood-Mana density
- regeneration interaction

## Bloodhook Chain

Damage is not its primary purpose.

Range and structural control improve significantly through higher INT and Blood affinity.

---

# 22. Elemental Confluence — Updated Standalone Spells

| Spell | Affinity | New Working Output |
|---|---|---:|
| **Crimson Needle Rain** | Blood | **~720,000 AP** |
| **Blood Prison** | Blood | **~360,000 AP + binding** |
| **Sanguine Brand** | Blood | **~480,000 AP** |
| **Thunder Cage** | Lightning | **~810,000 AP distributed** |
| **Astral Rail** | Lightning | **~1,390,000 AP** |
| **Inferno Lance** | Flame | **~880,000 AP** |
| **Cinderfield** | Flame | **~135,000 AP/sec** |
| **Phoenix Burst** | Flame | **~1,420,000 AP** |
| **Glacial Coffin** | Frost | **~550,000 AP** |
| **Whiteout Field** | Frost | **~65,000 AP/sec** |
| **Permafrost Spear** | Frost | **~920,000 AP** |
| **Radiant Lance** | Light | **~640,000 AP** |
| **Crescent Severance** | Lunar | **~675,000 AP** |
| **Starpiercer** | Starlight | **~1,140,000 AP** |
| **Constellation Array** | Starlight | **~1,350,000 AP total** |
| **Falling Star** | Starlight | **~1,560,000 AP** |
| **Gale Blade** | Wind | **~330,000 AP** |
| **Vacuum Breaker** | Wind | **~900,000 AP** |

Mana costs remain at their prior working values unless a future scene explicitly upgrades spell efficiency.

---

# 23. Updated Two-Affinity Spells

Multi-affinity spell scaling uses the combined affinity improvement as one woven structure.

The affinities are **not multiplied independently against each other**.

| Spell | Affinities | New Working Output |
|---|---|---:|
| **Inferno Cyclone** | Flame + Wind | **~1,750,000 AP** |
| **Glacial Tempest** | Frost + Wind | **~1,270,000 AP** |
| **Skybreaker Storm** | Lightning + Wind | **~1,770,000 AP distributed** |
| **Moonfrost Coffin** | Lunar + Frost | **~1,140,000 AP** |
| **Astral Thunderbolt** | Starlight + Lightning | **~2,210,000 AP** |
| **Solarflare Spear** | Flame + Light | **~2,090,000 AP** |
| **Crimson Permafrost** | Blood + Frost | **~985,000 AP + internal control** |
| **Crimson Thunderbrand** | Blood + Lightning | **~1,420,000 AP** |
| **Radiant Gale** | Light + Wind | **~1,280,000 AP distributed** |
| **Comet Spear** | Starlight + Wind | **~1,500,000 AP** |

---

# 24. Updated Three-Affinity Spells

| Spell | Affinities | New Working Output |
|---|---|---:|
| **Celestial Trinity — Trinity Beam** | Light + Lunar + Starlight | **~2,140,000 AP** |
| **Heavenfire Tempest** | Flame + Wind + Lightning | **~2,470,000 AP distributed** |
| **Moonlit Whiteout** | Frost + Wind + Lunar | **~1,410,000 AP over duration** |
| **Astral Raystorm** | Light + Starlight + Wind | **~2,660,000 AP if converged** |

Support modes of Celestial Trinity also improve substantially:

### Trinity Aegis

Improved:

- curse defense
- darkness defense
- corruption defense
- hostile soul-effect resistance
- Mana stabilization

### Trinity Restoration

Improved:

- tissue repair support
- Mana-pathway stabilization
- purification
- celestial reinforcement

---

# 25. Martial Techniques

## Burst Fist — Great Sage Technique

The original Silver version multiplied STR-derived physical AP by:

# **×3**

After Intermediate Silver and fourfold racial vessel reconstruction:

# **×4**

Current raw title-adjusted physical AP:

**~63,456**

Current perfect Burst Fist:

# **~253,824 AP**

before:

- Lightning reinforcement
- weapon effects
- momentum
- external buffs
- further martial modifiers

Burst Fist still multiplies **physical AP**, not STR itself.

---

# 26. Heaven-Treading Step

Great Sage Technique:

# **2 / 81**

Current state:

**Learned framework / developing mastery**

The stronger racial vessel improves its viability because Alok now possesses:

- stronger legs
- stronger joints
- superior aerial balance
- racial wings
- Valkyrie movement pathways
- improved Mana platforms
- higher Mana throughput

It does not become automatically mastered.

---

# 27. Graceful Strike

Previous current-status working output:

- ~140,000 AP uninfused
- ~250,000+ AP with Aetheryn + affinity

## New Uninfused Working Output

# **~210,000 AP**

## Aetheryn + Elemental Infusion

Depending on affinity:

# **~650,000–845,000+ AP**

Typical higher outputs:

- Flame / Light infusion near the top of the range
- Blood / Starlight / Wind near the middle
- Frost near the lower end
- Lightning retains exceptional penetration despite not always producing the numerically highest slash

Graceful Strike remains a technique of precision and transfer efficiency rather than raw explosion.

---

# 28. Adulian Vampiric Blade Art

Alok's improved race and Blood affinity greatly strengthen Forms I–III.

However:

# **Forms IV–VII remain restricted by energy-system requirements.**

Current access:

- Form I — Crimson Fang: **Usable**
- Form II — Bloodwake: **Usable**
- Form III — Scarlet Thread: **Usable**
- Form IV — Crimson Hunt: **Locked without Blood Aura**
- Form V — Thousand Crimson Fangs: **Locked without Blood Aura**
- Form VI — Adulian Blood Moon: **Locked without Crimson Qi**
- Form VII — Crimson Eclipse of Adulia: **Locked without advanced Crimson Qi**

Higher Mana and racial power do not automatically create Aura or Qi.

---

# 29. Mana Overdrive

Current multiplier remains:

# **×4 Mana Output**

The multiplier itself does not increase yet.

However the racial vessel makes it substantially safer because:

- Mana channels are stronger
- Demon Heart supports regeneration
- Dragon Heart supports throughput
- Angel Core stabilizes Mana
- Valkyrie lattice improves bodily synchronization

Prolonged use still creates meaningful stress.

---

# 30. Corpse Explosion

Previous:

# **~10,400 AP + 62% of corpse maximum HP**

New base term after ×1.50 general scaling:

# **~15,600 AP + 62% of corpse maximum HP**

The percentage component remains unchanged.

Higher-Tier corpses remain overwhelmingly more important than the flat base term.

---

# 31. Divine Skills — Updated

Divine Skills receive:

- Intermediate Silver scaling
- racial-vessel scaling
- relevant affinity recalculation

Their DP costs remain unchanged unless listed otherwise.

## Solar Judgment Beam

Previous:

**~300,000 AP/sec**

New:

# **~1,010,000 AP/sec**

Cost:

**10 DP/sec**

### Overcharged Mode

Previous:

**~700,000–750,000 AP/sec**

New:

# **~2,360,000–2,530,000 AP/sec**

Cost:

**25 DP/sec**

The beam benefits enormously from Flame's new racial state.

---

## Absolute Stillness

Previous initial output:

**~450,000 AP**

New:

# **~1,180,000 AP initial equivalent**

Working radius increases from roughly 100 m to approximately:

# **~150 m**

Cost remains:

**60 DP activation**

Optional sustain:

**5 DP/sec**

Its real value remains:

- thermal suppression
- movement denial
- Mana slowing
- spell interference
- Divine Frost persistence

---

## Heavenfall Thunder Lance

Previous direct output:

**~1,000,000 AP**

New:

# **~2,900,000 AP direct**

Previous secondary center discharge:

**~250,000 AP**

New:

# **~725,000 AP near impact center**

Working catastrophic secondary radius:

# **~375 m**

Cost remains:

# **100 DP**

The updated value already includes the new Lightning state.

Do not add +325% again.

---

# 32. Divine Skill Hierarchy

| Skill | Main Role | Cost | New Working Output |
|---|---|---:|---:|
| **Solar Judgment Beam** | Sustained Divine Flame destruction | 10 DP/sec | **~1.01M AP/sec** |
| **Absolute Stillness** | Divine Frost control | 60 DP | **~1.18M AP initial** |
| **Heavenfall Thunder Lance** | Catastrophic Divine Lightning | 100 DP | **~2.90M AP direct** |

---

# 33. Aetheryn / Primal Eclipse

Aetheryn remains:

# **#27 — PRIMAL ECLIPSE**

Current rarity:

**Mythic**

The racial awakening improves synchronization.

## Recognized Stable Affinities

Aetheryn may now safely conduct all eight of Alok's stable affinities:

- Blood
- Lightning
- Flame
- Frost
- Light
- Lunar
- Starlight
- Wind

## Multi-Affinity Conduction

- 1 affinity — effortless
- 2 affinities — fully stable
- 3 affinities — stable
- 4 affinities — possible / controlled
- 5+ — unstable
- all 8 — unsafe

Aetheryn remains the safest medium for experimental multi-affinity martial techniques.

---

# 34. Twin Grave — Updated

Twin Grave scales with the stronger Intermediate-Silver user and racial vessel.

General weapon-output increase:

# **×1.50**

## Standard Form

Previous twin-barrel impact:

**94,500 AP**

New:

# **141,750 AP**

Previous Gravefire Burn:

**7,560 AP/sec**

New:

# **11,340 AP/sec**

15-second maximum burn:

# **170,100 AP**

Total maximum potential per trigger:

# **311,850 AP**

## Rapidfire Form

Previous impact:

**66,150 AP**

New:

# **99,225 AP**

Previous burn:

**5,292 AP/sec**

New:

# **7,938 AP/sec**

15-second maximum burn:

# **119,070 AP**

Total maximum potential:

# **218,295 AP / trigger**

## Gravefire Collapse

Mechanic remains:

**100% of remaining stored burn damage is detonated immediately.**

No artificial bonus is added.

---

# 35. Divine Regeneration — Racial Upgrade

Divine Regeneration improves through the interaction of:

- Life lineage
- Death lineage
- Demon Heart
- Dragon Heart
- Angel Core
- stronger VIT
- stronger Mana recovery

Current improvements:

- faster deep-tissue reconstruction
- improved bone regeneration
- stronger organ restoration
- improved toxin purge
- improved corruption purge
- reduced instability when regenerating during high-output combat
- better tolerance for Mana Overdrive
- improved recovery from racial transformation strain

It still does not automatically defeat:

- soul destruction
- conceptual erasure
- superior sealing
- sufficiently powerful anti-regeneration
- Law suppression
- Void contamination

---

# 36. Worldsense — Racial Integration

Worldsense remains Epic.

The raw range increases naturally through higher INT.

The largest change is not radius.

It is **resolution**.

Worldsense now works in conjunction with:

- Dragon Vision
- Demon Sense
- Angelic Mana purity
- Valkyrie battle instinct

This gives Alok simultaneous access to:

- large-scale location data
- detailed Mana pathways
- spell construction
- hostile intent
- combat trajectories
- magical weak points
- battlefield movement

---

# 37. Wings and Flight

Alok can manifest racial wings voluntarily.

## Draconic Wings

Best for:

- explosive acceleration
- physical aerial combat
- heavy turning force
- close-range collision stability

## Angelic Wings

Best for:

- sustained Mana-efficient flight
- celestial maneuvering
- Light conduction
- purification
- long-duration aerial control

## Valkyrie Integration

The Valkyrie battle lattice improves both forms through:

- balance
- directional correction
- weapon use in flight
- combat footwork translated into three dimensions

Skystride remains useful—

but is no longer Alok's only reliable method of sustained aerial movement.

---

# 38. Physical Vessel Saturation

Current Intermediate → Advanced Silver track:

| Track | Completion |
|---|---:|
| **Physical Vessel** | **~50%** |
| **Mana Core** | **100%** |
| **Overall Completion** | **~50%** |

Rule:

# **Overall Completion = lower track**

Therefore Alok remains Intermediate Silver.

He cannot advance to Advanced Silver until the Physical Vessel also reaches saturation and the breakthrough requirements are met.

---

# 39. Mana-Core Saturation and Overflow

Because the Mana-Core track is already:

# **100%**

further permanent magical growth may be:

- held as overflow
- redirected into Star stability
- used to densify racial Mana organs
- stored toward the next breakthrough
- expressed as affinity refinement
- expressed as Mana quality rather than immediate visible INT

This prevents the saturated Mana side from wasting future development.

---

# 40. Current Combat Identity

Intermediate-Silver Alok is no longer merely a powerful mage with exceptional physicality.

His current identity is becoming:

# **Hybrid Divine-Born War-Mage / Racial Vessel / Sovereign**

He can now fight through:

- high-output elemental magic
- multi-affinity confluence
- Divine Skills
- swordsmanship
- Great Sage techniques
- physical combat
- racial traits
- aerial combat
- Shadows
- Eternal Legion
- Soul authority
- Life / Death reconstruction

The four racial lines increase versatility without replacing his existing Class identity.

---

# 41. Updated Signature Spell Set

## Standalone

- Astral Rail — ~1.39M AP
- Phoenix Burst — ~1.42M AP
- Permafrost Spear — ~920k AP
- Radiant Lance — ~640k AP
- Starpiercer — ~1.14M AP
- Falling Star — ~1.56M AP

## Two-Affinity

- Astral Thunderbolt — ~2.21M AP
- Solarflare Spear — ~2.09M AP
- Inferno Cyclone — ~1.75M AP
- Skybreaker Storm — ~1.77M AP

## Three-Affinity

- Trinity Beam — ~2.14M AP
- Heavenfire Tempest — ~2.47M AP
- Astral Raystorm — ~2.66M AP
- Moonlit Whiteout — ~1.41M AP

## Divine

- Solar Judgment Beam — ~1.01M AP/sec
- Absolute Stillness — ~1.18M AP initial + suppression
- Heavenfall Thunder Lance — ~2.90M AP direct

---

# 42. Numeric Quick Reference

| Category | Intermediate-Silver State |
|---|---:|
| Tier | **Intermediate Silver** |
| Overall toward Advanced | **~50%** |
| Physical Vessel | **~50%** |
| Mana Core | **100%** |
| STR | **5,288** |
| AGI | **5,324** |
| VIT | **5,306** |
| INT | **8,200** |
| Effective STR | **~6,346** |
| Effective AGI | **~6,389** |
| Effective VIT | **~6,367** |
| Effective INT | **9,840** |
| Divinity | **6,520** |
| Natural Mana | **820,000** |
| Mana Recovery | **~1,100/sec** |
| Divinity Recovery | **840/hour** |
| Raw Physical AP | **~63,456** |
| Burst Fist | **~253,824 AP / ×4** |
| Mana Bullet | **~6,000 AP** |
| Astral Rail | **~1.39M AP** |
| Phoenix Burst | **~1.42M AP** |
| Astral Thunderbolt | **~2.21M AP** |
| Solarflare Spear | **~2.09M AP** |
| Heavenfire Tempest | **~2.47M AP** |
| Astral Raystorm | **~2.66M AP** |
| Solar Judgment Beam | **~1.01M AP/sec** |
| Absolute Stillness | **~1.18M AP initial** |
| Heavenfall Thunder Lance | **~2.90M AP direct** |

---

# 43. Current Affinity Quick Reference

| Affinity | Damage / Effectiveness |
|---|---:|
| Blood | **+300%** |
| Lightning | **+325%** |
| Flame | **+350%** |
| Frost | **+250%** |
| Light | **+350%** |
| Lunar | **+275%** |
| Starlight | **+300%** |
| Wind | **+300%** |

---

# 44. Canon Locks

- Alok is now **Intermediate Silver**.
- Intermediate Silver grants **+250 STR / AGI / VIT / INT / Divinity**.
- Existing Skill / Spell output receives **×1.25** substage scaling.
- Fourfold racial vessel reinforcement then provides **×1.20** general output scaling.
- General non-affinity output therefore scales by **×1.50** from the prior Beginner-Silver working value.
- Affinity-dependent Skills are additionally recalculated against their new affinity values.
- Physical Vessel is approximately **50% toward Advanced Silver**.
- Mana-Core Saturation is **100% toward Advanced Silver**.
- Overall progression is approximately **50%**, because the weaker track limits advancement.
- Natural Mana is **820,000** from INT.
- Mana recovery is approximately **1,100/sec**.
- Divinity is **6,520**.
- Divinity recovery is **840/hour**.
- Alok possesses a functional **Dragon Heart**.
- Alok possesses a functional **Demon Heart**.
- Alok possesses a functional **Angel Core**.
- Valkyrie inheritance manifests primarily as a **Battle Lattice / war-body structure**.
- Fourfold Silver-stage racial manifestation is complete.
- Alok may voluntarily manifest or dismiss racial traits.
- Current controllable manifestations include **wings, horns, scales, markings, pupils, claws, battle runes, and related racial sensory traits**.
- Traits become more complete and powerful with later substages and Tiers.
- Dragon Vision is active.
- Demon Sense is active.
- Bloodline traits remain distinct; full Aeonmorta racial merger has **not** occurred.
- Burst Fist now scales STR-derived physical AP by **×4**.
- Adulian Forms IV–VII remain inaccessible without Blood Aura / Crimson Qi.
- Mana Overdrive remains **×4**.
- Two-affinity Confluence is fully stable.
- Three-affinity Confluence is stable.
- Four-affinity Confluence is conditionally possible.
- Eightfold Confluence remains unsafe.
- Aetheryn can safely conduct all eight stable affinities individually.
- Divine Skill costs remain unchanged for now.
- Racial advancement improves power and efficiency but does not remove Tier, Law, Aura/Qi, or breakthrough requirements.
